<?php
require_once '../src/config/database.php';
require_once '../src/controllers/EmailController.php';

session_start();

$controller = new EmailController();

if (isset($_GET['action'])) {
    $action = $_GET['action'];
    switch ($action) {
        case 'login':
            $controller->login();
            break;
        case 'register':
            $controller->register();
            break;
        case 'inbox':
            $controller->getInbox();
            break;
        case 'view':
            $controller->viewEmail($_GET['id']);
            break;
        case 'delete':
            $controller->deleteEmails($_POST['emails']);
            break;
        default:
            $controller->getInbox();
            break;
    }
} else {
    $controller->getInbox();
}
?>