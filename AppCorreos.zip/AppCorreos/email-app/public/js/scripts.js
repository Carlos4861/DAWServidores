document.addEventListener('DOMContentLoaded', function() {
    const deleteButtons = document.querySelectorAll('.delete-button');
    const checkboxes = document.querySelectorAll('.email-checkbox');
    const deleteSelectedButton = document.getElementById('delete-selected');

    // Handle delete button click
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const emailId = this.dataset.emailId;
            deleteEmail(emailId);
        });
    });

    // Handle delete selected emails
    deleteSelectedButton.addEventListener('click', function() {
        const selectedEmails = Array.from(checkboxes)
            .filter(checkbox => checkbox.checked)
            .map(checkbox => checkbox.value);

        if (selectedEmails.length > 0) {
            deleteEmails(selectedEmails);
        } else {
            alert('Please select at least one email to delete.');
        }
    });

    function deleteEmail(emailId) {
        // AJAX request to delete a single email
        fetch(`/delete.php?id=${emailId}`, {
            method: 'DELETE'
        })
        .then(response => {
            if (response.ok) {
                alert('Email deleted successfully.');
                location.reload();
            } else {
                alert('Error deleting email.');
            }
        });
    }

    function deleteEmails(emailIds) {
        // AJAX request to delete multiple emails
        fetch('/delete.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ ids: emailIds })
        })
        .then(response => {
            if (response.ok) {
                alert('Selected emails deleted successfully.');
                location.reload();
            } else {
                alert('Error deleting selected emails.');
            }
        });
    }
});