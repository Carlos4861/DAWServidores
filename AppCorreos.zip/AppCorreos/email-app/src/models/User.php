class User {
    private $id;
    private $username;
    private $password;

    public function __construct($username, $password) {
        $this->username = $username;
        $this->password = password_hash($password, PASSWORD_DEFAULT);
    }

    public function getId() {
        return $this->id;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function verifyPassword($password) {
        return password_verify($password, $this->password);
    }

    public static function register($username, $password) {
        // Logic to register the user in the database
    }

    public static function authenticate($username, $password) {
        // Logic to authenticate the user
    }
}