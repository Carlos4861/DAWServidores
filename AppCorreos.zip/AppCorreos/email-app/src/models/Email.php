<?php

class Email {
    private $id;
    private $sender;
    private $recipient;
    private $subject;
    private $body;

    public function __construct($id, $sender, $recipient, $subject, $body) {
        $this->id = $id;
        $this->sender = $sender;
        $this->recipient = $recipient;
        $this->subject = $subject;
        $this->body = $body;
    }

    public function getId() {
        return $this->id;
    }

    public function getSender() {
        return $this->sender;
    }

    public function getRecipient() {
        return $this->recipient;
    }

    public function getSubject() {
        return $this->subject;
    }

    public function getBody() {
        return $this->body;
    }

    public static function createEmail($sender, $recipient, $subject, $body) {
    }

    public static function retrieveEmails($recipient) {
    }
}