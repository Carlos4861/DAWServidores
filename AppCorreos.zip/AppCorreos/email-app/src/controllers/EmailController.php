<?php

class EmailController {
    private $userModel;
    private $emailModel;

    public function __construct($userModel, $emailModel) {
        $this->userModel = $userModel;
        $this->emailModel = $emailModel;
    }

    public function login($username, $password) {
        return $this->userModel->authenticate($username, $password);
    }

    public function register($username, $password) {
        return $this->userModel->register($username, $password);
    }

    public function getInbox($userId) {
        return $this->emailModel->getEmailsByUserId($userId);
    }

    public function viewEmail($emailId) {
        return $this->emailModel->getEmailById($emailId);
    }

    public function deleteEmails($emailIds) {
        return $this->emailModel->deleteEmailsByIds($emailIds);
    }
}