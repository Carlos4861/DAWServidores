<?php
session_start();
require_once '../controllers/EmailController.php';

$emailController = new EmailController();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$emails = $emailController->getInbox($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Inbox</title>
</head>
<body>
    <h1>Inbox</h1>
    <form action="delete.php" method="POST">
        <table>
            <thead>
                <tr>
                    <th>Select</th>
                    <th>Sender</th>
                    <th>Subject</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($emails as $email): ?>
                    <tr>
                        <td><input type="checkbox" name="emails[]" value="<?php echo $email->id; ?>"></td>
                        <td><?php echo htmlspecialchars($email->sender); ?></td>
                        <td><a href="email.php?id=<?php echo $email->id; ?>"><?php echo htmlspecialchars($email->subject); ?></a></td>
                        <td><?php echo htmlspecialchars($email->date); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <button type="submit">Delete Selected</button>
    </form>
</body>
</html>