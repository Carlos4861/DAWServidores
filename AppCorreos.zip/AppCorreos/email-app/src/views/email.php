<?php
session_start();
require_once '../models/Email.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$emailId = $_GET['id'] ?? null;

if ($emailId) {
    $emailModel = new Email();
    $email = $emailModel->getEmailById($emailId);
} else {
    header('Location: inbox.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Email View</title>
</head>
<body>
    <div class="container">
        <h1><?php echo htmlspecialchars($email['subject']); ?></h1>
        <p><strong>From:</strong> <?php echo htmlspecialchars($email['sender']); ?></p>
        <p><strong>To:</strong> <?php echo htmlspecialchars($email['recipient']); ?></p>
        <div class="email-body">
            <?php echo nl2br(htmlspecialchars($email['body'])); ?>
        </div>
        <a href="inbox.php">Back to Inbox</a>
    </div>
</body>
</html>