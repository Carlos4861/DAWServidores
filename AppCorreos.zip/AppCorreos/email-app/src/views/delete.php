<?php
session_start();
require_once '../controllers/EmailController.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$emailController = new EmailController();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    if (!empty($_POST['emails'])) {
        $emailIds = $_POST['emails'];
        $emailController->deleteEmails($emailIds);
        header('Location: inbox.php?message=Emails deleted successfully');
        exit();
    } else {
        header('Location: inbox.php?error=No emails selected');
        exit();
    }
}
?>