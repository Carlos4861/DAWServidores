# Email Application

This is a simple email application built with PHP that allows users to register, log in, and manage their emails. Users can send, receive, and delete emails, with a user-friendly interface for managing their inbox.

## Features

- User registration and authentication
- Inbox displaying emails for the logged-in user
- View individual email content
- Multi-selection of emails for deletion

## Project Structure

```
email-app
├── src
│   ├── controllers
│   │   └── EmailController.php
│   ├── models
│   │   └── User.php
│   │   └── Email.php
│   ├── views
│   │   ├── login.php
│   │   ├── register.php
│   │   ├── inbox.php
│   │   ├── email.php
│   │   └── delete.php
│   └── config
│       └── database.php
├── public
│   ├── index.php
│   ├── css
│   │   └── styles.css
│   └── js
│       └── scripts.js
├── composer.json
└── README.md
```

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/email-app.git
   ```

2. Navigate to the project directory:
   ```
   cd email-app
   ```

3. Install dependencies using Composer:
   ```
   composer install
   ```

4. Configure your database settings in `src/config/database.php`.

5. Start a local server (e.g., using PHP's built-in server):
   ```
   php -S localhost:8000 -t public
   ```

6. Access the application in your web browser at `http://localhost:8000`.

## Usage

- **Register**: Create a new account by filling out the registration form.
- **Login**: Access your account using your credentials.
- **Inbox**: View your emails, select multiple emails to delete, and manage your inbox.
- **View Email**: Click on an email to see its content.

## Contributing

Feel free to submit issues or pull requests for improvements or bug fixes.

## License

This project is open-source and available under the MIT License.