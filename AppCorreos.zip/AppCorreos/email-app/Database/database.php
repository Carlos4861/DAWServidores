<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "database_name";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Read SQL file
$sql = file_get_contents('path/to/your/sqlfile.sql');

// Execute SQL file
if ($conn->multi_query($sql) === TRUE) {
    echo "SQL file executed successfully";
} else {
    echo "Error executing SQL file: " . $conn->error;
}

$conn->close();
?>